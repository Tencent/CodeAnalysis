var s="/document/assets/Nodemanagement.f5415093.png",a="/document/assets/ProcessConfiguration2.b0d699f7.png";export{s as _,a};
