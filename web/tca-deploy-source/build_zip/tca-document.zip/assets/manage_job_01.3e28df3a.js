var a="/document/assets/manage_job_01.c9185509.png";export{a as _};
