var a="/document/assets/golangcilint.e31f929a.jpg",s="/document/assets/golangcilintversion.afbdeff6.jpg";export{a as _,s as a};
