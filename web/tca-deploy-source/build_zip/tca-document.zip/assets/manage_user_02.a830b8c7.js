const s="/document/assets/manage_user_01.b9bd1cc2.png",e="/document/assets/manage_user_02.f8f273e7.png";export{s as _,e as a};
