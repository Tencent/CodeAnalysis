var a="/document/assets/manage_tool_01.90fd47ba.png";export{a as _};
