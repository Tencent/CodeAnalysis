import{_ as e,o as c,c as r}from"./app.5af60d8e.js";const t={};function _(n,o){return c(),r("div")}var s=e(t,[["render",_],["__file","index.html.vue"]]);export{s as default};
