const s="/document/assets/personalToken.379b8f35.png";export{s as _};
