import{_}from"./app.e60430f3.js";const e={};function r(t,c){return null}var f=_(e,[["render",r],["__file","404.html.vue"]]);export{f as default};
