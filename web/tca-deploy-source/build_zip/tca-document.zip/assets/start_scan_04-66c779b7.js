const s="/document/assets/start_scan_06-2c5547b2.png",t="/document/assets/start_scan_05-c09d1528.png",a="/document/assets/start_scan_04-263a94c3.png";export{s as _,t as a,a as b};
