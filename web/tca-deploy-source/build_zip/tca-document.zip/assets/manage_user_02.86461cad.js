var s="/document/assets/manage_user_01.b9bd1cc2.png",a="/document/assets/manage_user_02.f8f273e7.png";export{s as _,a};
