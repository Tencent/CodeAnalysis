const s="/document/assets/addcustomrules-220aab00.png",t="/document/assets/createcustomrule-54c07258.png";export{s as _,t as a};
