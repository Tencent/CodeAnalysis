import{_ as e}from"./app.b27111be.js";const _={};function r(n,t){return null}var f=e(_,[["render",r],["__file","index.html.vue"]]);export{f as default};
