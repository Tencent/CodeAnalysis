const s="/document/assets/AddRule-868e55e0.png",t="/document/assets/AddRule2-84297356.png",e="/document/assets/AddRule3-c3402a44.png";export{s as _,t as a,e as b};
