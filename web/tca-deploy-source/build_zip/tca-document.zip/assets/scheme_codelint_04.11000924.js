var e="/document/assets/scheme_codelint_04.a63f9fcd.png";export{e as _};
