var e="/CodeAnalysis/assets/scheme_template_01.a3dfedfe.png",s="/CodeAnalysis/assets/scheme_template_02.525ea38c.png";export{e as _,s as a};
