var s="/document/assets/addcustomrules.220aab00.png",a="/document/assets/createcustomrule.54c07258.png";export{a as _,s as a};
