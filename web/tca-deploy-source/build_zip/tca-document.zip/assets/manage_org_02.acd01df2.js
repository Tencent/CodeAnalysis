var a="/document/assets/manage_org_01.4220e65f.png",s="/document/assets/manage_org_02.d813adb5.png";export{a as _,s as a};
