var e="/CodeAnalysis/assets/team_member.e8f39fb8.png";export{e as _};
