var s="/document/assets/start_scan_02.cf8dcc61.png";export{s as _};
