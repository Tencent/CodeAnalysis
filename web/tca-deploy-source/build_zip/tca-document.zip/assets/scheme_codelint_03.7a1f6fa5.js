var e="/document/assets/scheme_codelint_02.0beb83d6.png",s="/document/assets/scheme_codelint_03.dd3c48db.png";export{e as _,s as a};
