const s="/document/assets/scheme_codelint_01-3a155b75.png";export{s as _};
